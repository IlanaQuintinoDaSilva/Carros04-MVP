package br.com.livroandroid.carros.activity.login

interface LoginView {
    fun showError(msg: Int)
    fun alert(msg_ok: Int)
    fun alert(msg_ok: String)
    fun showProgress()
    fun loginOk()
}
package br.com.livroandroid.carros.activity.login

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import br.com.livroandroid.carros.R
import br.com.livroandroid.carros.activity.carros.CarrosActivity
import br.com.livroandroid.carros.extensions.setupToolbar
import kotlinx.android.synthetic.main.activity_login.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast

class LoginActivity : AppCompatActivity() {

    private val presenter: LoginPresenter by lazy {
        LoginPresenter(view)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        setupToolbar(R.id.toolbar)

        btLogin.setOnClickListener { onClickLogin() }

        presenter.onCreate()
    }

    @SuppressLint("CheckResult")
    private fun onClickLogin() {

        val login = tLogin.text.toString()
        val senha = tSenha.text.toString()

        presenter.onClickLogin(login, senha)
    }

    /**
     * View
     */
    private val view = object: LoginView {
        override fun showProgress() {
            progress.visibility = View.VISIBLE
        }

        override fun loginOk() {
            startActivity<CarrosActivity>()

            finish()
        }

        override fun alert(msg: String) {
            toast(msg)
        }

        override fun alert(msg: Int) {
            toast(msg)
        }

        override fun showError(messageResId: Int) {
            alert(messageResource = messageResId, titleResource = R.string.error).show()
        }
    }
}
